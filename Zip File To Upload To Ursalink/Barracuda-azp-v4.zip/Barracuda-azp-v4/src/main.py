import socket
import json
import urllib
import os
import time
import random
import thread
import Queue

# Configuration
HOST = '192.168.1.1'
PORT = 502
INTERNET_TEST_URL = 'http://www.google.com'
LOCAL_FILE = '/tmp/local_vessel.json'
UPLOAD_URL = 'http://37.60.247.110:2024/upload'  # Replace with your actual endpoint
VESSEL_NUMBER = '14'
data_queue = Queue.Queue()  # Queue to handle incoming data
lock = thread.allocate_lock()  # Lock to handle safe access to local data
internet_connected = True  # Track internet connection status


def check_internet():
    """Check if internet connection is available."""
    global internet_connected
    try:
        response = urllib.urlopen(INTERNET_TEST_URL)
        if response.getcode() == 200:
            internet_connected = True
            return True
    except IOError:
        internet_connected = False
    return False


def generate_unique_id():
    """Generate a unique ID in the format AZP-{randomnumber}."""
    random_number = random.randint(1000, 9999)
    return "AZP-{}".format(random_number)


def save_data_locally(data):
    """Save data from the queue to a local JSON file."""
    with lock:
        if os.path.exists(LOCAL_FILE):
            with open(LOCAL_FILE, 'r') as f:
                existing_data = json.load(f)
        else:
            existing_data = []

        for entry in data:
            unique_id = generate_unique_id()  # Generate unique ID for each entry
            entry_data = {
                'VesselNumber': VESSEL_NUMBER,
                'UniqueID': unique_id,
                'RawData': entry
            }
            existing_data.append(entry_data)

            # Log the data being saved
            print("Saving to local file: {}".format(entry_data))

        with open(LOCAL_FILE, 'w') as f:
            json.dump(existing_data, f, indent=4)


def upload_data():
    """Upload data from the local file to the server."""
    while True:
        if os.path.exists(LOCAL_FILE):
            try:
                with lock:
                    with open(LOCAL_FILE, 'r') as f:
                        data = json.load(f)

                if not data:
                    print("No data to upload.")
                    time.sleep(10)  # Check for upload every 10 seconds
                    continue

                payload = {
                    "VesselNumber": VESSEL_NUMBER,
                    "data": data
                }

                # Log the data being sent
                print("Uploading data to server: {}".format(json.dumps(payload, indent=4)))

                # Using urllib instead of requests for POST
                req = urllib.urlopen(UPLOAD_URL, json.dumps(payload))

                if req.getcode() == 200:
                    print("Data successfully uploaded.")
                    with lock:
                        os.remove(LOCAL_FILE)  # Remove the local file after successful upload
                else:
                    print("Failed to upload data. Status code: {}".format(req.getcode()))

            except (IOError, json.JSONDecodeError) as e:
                print("Error during upload: {}".format(e))

        time.sleep(10)  # Check for upload every 10 seconds


def process_data(data):
    """Process the received data as a string and filter only data starting with '$'."""
    try:
        decoded_data = data.decode('ascii', errors='ignore')
        cleaned_data = decoded_data.strip().replace('\r', '').replace('\n', '')

        # Log the raw data received from the socket
        print("Raw data received: {}".format(cleaned_data))

        if cleaned_data.startswith('$'):
            return [cleaned_data]
        else:
            return []
    except Exception as e:
        print("Error processing data: {}".format(e))
        return []


def receive_data():
    """Receive data from TCP and save to queue."""
    while True:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.connect((HOST, PORT))
            print("Connected to {}:{}".format(HOST, PORT))

            while True:
                try:
                    data = s.recv(1024)
                    if not data:
                        print("No data received or connection closed.")
                        break

                    string_data_list = process_data(data)
                    if string_data_list:
                        data_queue.put(string_data_list)  # Add data to the queue
                        print("Data added to queue: {}".format(string_data_list))

                except socket.error:
                    print("Connection was forcibly closed by the remote host. Reconnecting...")
                    break

        except socket.error as e:
            print("Connection error: {}. Reconnecting in 60 seconds...".format(e))
            time.sleep(60)  # Reconnect after a delay


def monitor_internet():
    """Periodically check internet connectivity."""
    while True:
        if not check_internet():
            print("Internet is not available.")
        else:
            print("Internet is available.")
        time.sleep(3600)  # Check every hour


def main():
    """Main function that runs the receive and upload threads."""

    # Thread to save data from queue locally
    def queue_to_local():
        while True:
            if not data_queue.empty():
                data_list = data_queue.get()
                save_data_locally(data_list)
            time.sleep(1)

    # Start the TCP receive thread
    thread.start_new_thread(receive_data, ())

    # Start the local save thread
    thread.start_new_thread(queue_to_local, ())

    # Start the upload thread
    thread.start_new_thread(upload_data, ())

    # Start the internet monitoring thread
    thread.start_new_thread(monitor_internet, ())

    # Keep the main thread alive
    while True:
        time.sleep(1)


if __name__ == "__main__":
    main()
