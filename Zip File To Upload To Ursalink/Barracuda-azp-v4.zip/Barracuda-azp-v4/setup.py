from setuptools import setup, find_packages
setup(
    name='BusTrackingAZP',
    sdk_version='1.0.5',
    version='0.0.1',
    author='whb',
    author_email='director@azmiproductions.com',
    description='',
    license='PRIVATE',
    packages = find_packages('src'),
    package_dir={ '' : 'src' },
    zip_safe=False,
    install_requires=[
    ],
    entry_points = """
        [console_scripts]
        BusTrackingAZP = Application:main
        """
)